module.exports = {
  dist: {
    src: ["<%= buildDir %>"]
  }
};
