module.exports = {
  javascripts: {
    files: [
      "<%= srcDir %>/**/*.js",
      "stylesheets/image-projection.css"
    ],

    tasks: [
      "build"
    ]
  }
};
