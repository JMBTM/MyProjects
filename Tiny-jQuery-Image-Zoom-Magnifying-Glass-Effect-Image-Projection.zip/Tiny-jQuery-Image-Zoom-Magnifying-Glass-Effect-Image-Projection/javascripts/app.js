$(document).ready(function(){

  $(".wrap").imageProjection();
  //$(".wrap").imageProjection("destroy");

});
